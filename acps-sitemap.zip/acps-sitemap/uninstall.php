<?php
/**
 * Uninstall cleanup: remove settings and cached data.
 *
 * @package ACPS_Sitemap
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Settings and internal options.
delete_option( 'acps_sitemap_settings' );
delete_option( 'acps_sitemap_cache_buster' );
delete_option( 'acps_sitemap_verified' );
delete_option( 'acps_sitemap_update_failed' );
delete_option( 'acps_sitemap_safe_mode' );
delete_option( 'acps_sitemap_issues' );
delete_option( 'acps_sitemap_remote_pw' );
delete_option( 'acps_sitemap_remote_last_edit' );
delete_option( 'acps_sitemap_selfheal' );

if ( function_exists( 'wp_clear_scheduled_hook' ) ) {
	wp_clear_scheduled_hook( 'acps_sitemap_selfheal_cron' );
}

// Update-lookup transients.
delete_transient( 'acps_sitemap_update_remote' );
delete_transient( 'acps_sitemap_devstatus' );

// Remove any leftover sitemap cache + remote session/rate transients.
global $wpdb;
$wpdb->query(
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '\_transient\_acps_sm\_%'
	    OR option_name LIKE '\_transient\_timeout\_acps_sm\_%'
	    OR option_name LIKE '\_transient\_acps_sitemap_remote\_%'
	    OR option_name LIKE '\_transient\_timeout\_acps_sitemap_remote\_%'"
);
