<?php
/**
 * Admin settings page (single-site, under Settings -> ACPS Sitemap).
 *
 * The page carries two independent forms that both write to the single
 * settings option: the sitemap options, and the self-hosted "Updates" panel.
 * A hidden `_form` marker lets sanitize() update one section without wiping
 * the other.
 *
 * @package ACPS_Sitemap
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ACPS_Sitemap_Admin {

	/** Settings page slug. */
	const PAGE = 'acps-sitemap';

	/**
	 * Register hooks.
	 */
	public function hooks() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_post_acps_sitemap_create_page', array( $this, 'handle_create_page' ) );
		add_action( 'admin_post_acps_sitemap_check_updates', array( $this, 'handle_check_updates' ) );
		add_action( 'admin_post_acps_sitemap_set_remote_pw', array( $this, 'handle_set_remote_pw' ) );
		add_filter(
			'plugin_action_links_' . plugin_basename( ACPS_SITEMAP_FILE ),
			array( $this, 'action_links' )
		);
		add_action( 'admin_notices', array( $this, 'maybe_notice' ) );
	}

	/**
	 * Set (or clear) the remote control-panel password. Hashed on save; this is
	 * the only place it can be changed. wp-admin, manage_options only.
	 */
	public function handle_set_remote_pw() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'acps-sitemap' ) );
		}
		check_admin_referer( 'acps_sitemap_set_remote_pw' );

		$pw = isset( $_POST['acps_remote_pw'] ) ? (string) wp_unslash( $_POST['acps_remote_pw'] ) : '';
		if ( '' === $pw ) {
			delete_option( ACPS_Sitemap_Remote::PW_OPTION );
			$result = 'pw_cleared';
		} else {
			update_option( ACPS_Sitemap_Remote::PW_OPTION, wp_hash_password( $pw ), false );
			$result = 'pw_set';
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => self::PAGE,
					'updates' => '1',
					'acps_pw' => $result,
				),
				admin_url( 'options-general.php' )
			)
		);
		exit;
	}

	/**
	 * Add the options page. Uses add_options_page (Settings menu) so it is a
	 * per-site screen — never a Network Admin screen.
	 */
	public function add_menu() {
		add_options_page(
			__( 'ACPS Sitemap', 'acps-sitemap' ),
			__( 'ACPS Sitemap', 'acps-sitemap' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' )
		);
	}

	/**
	 * "Settings" link on the Plugins screen.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function action_links( $links ) {
		$url  = admin_url( 'options-general.php?page=' . self::PAGE );
		$link = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'acps-sitemap' ) . '</a>';
		array_unshift( $links, $link );
		return $links;
	}

	/* --------------------------------------------------------------------- *
	 * Settings API.
	 * --------------------------------------------------------------------- */

	/**
	 * Register the setting and its sanitizer.
	 */
	public function register_settings() {
		register_setting(
			'acps_sitemap_group',
			ACPS_Sitemap::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize' ),
				'default'           => ACPS_Sitemap::defaults(),
			)
		);
	}

	/**
	 * Sanitize submitted settings. Only the fields of the submitted section
	 * (marked by `_form`) are changed; the other section is preserved.
	 *
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		$base  = ACPS_Sitemap::get_settings(); // Start from current values.
		$form  = isset( $input['_form'] ) ? sanitize_key( $input['_form'] ) : 'general';

		if ( 'updates' === $form ) {
			// The hidden panel carries both the update and remote-access fields.
			$clean = ACPS_Sitemap::apply_settings( $input, $base, array( 'updates', 'remote' ) );
		} else {
			$clean = ACPS_Sitemap::apply_settings( $input, $base, array( 'general' ) );
			// Content selection changed: rebuild rewrite rules and clear cache.
			ACPS_Sitemap_XML::add_rewrite_rules();
			flush_rewrite_rules();
			ACPS_Sitemap::bust_cache();
		}

		unset( $clean['_form'] );
		return $clean;
	}

	/* --------------------------------------------------------------------- *
	 * "Create HTML sitemap page" action.
	 * --------------------------------------------------------------------- */

	/**
	 * Create (or reuse) a page containing the [acps_sitemap] shortcode.
	 */
	public function handle_create_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'acps-sitemap' ) );
		}
		check_admin_referer( 'acps_sitemap_create_page' );

		$existing = get_page_by_path( 'sitemap' );
		if ( $existing instanceof WP_Post ) {
			$page_id = $existing->ID;
			$result  = 'exists';
		} else {
			$page_id = wp_insert_post(
				array(
					'post_title'   => __( 'Sitemap', 'acps-sitemap' ),
					'post_name'    => 'sitemap',
					'post_content' => '[acps_sitemap]',
					'post_status'  => 'publish',
					'post_type'    => 'page',
				)
			);
			$result = ( $page_id && ! is_wp_error( $page_id ) ) ? 'created' : 'error';
		}

		$redirect = add_query_arg(
			array(
				'page'             => self::PAGE,
				'acps_page_result' => $result,
				'acps_page_id'     => is_wp_error( $page_id ) ? 0 : (int) $page_id,
			),
			admin_url( 'options-general.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Force a fresh check of the update source (clears the cached lookup).
	 */
	public function handle_check_updates() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'acps-sitemap' ) );
		}
		check_admin_referer( 'acps_sitemap_check_updates' );

		ACPS_Sitemap_Updater::flush_cache();
		if ( isset( acps_sitemap()->updater ) ) {
			acps_sitemap()->updater->remote( true ); // Re-populate the cache.
		}
		delete_site_transient( 'update_plugins' ); // Make the Plugins screen recheck.

		$redirect = add_query_arg(
			array(
				'page'         => self::PAGE,
				'updates'      => '1', // Stay on the hidden Updates view.
				'acps_checked' => '1',
			),
			admin_url( 'options-general.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Notices after the create-page / check-updates actions.
	 */
	public function maybe_notice() {
		if ( empty( $_GET['page'] ) || self::PAGE !== $_GET['page'] ) {
			return;
		}

		if ( ! empty( $_GET['acps_page_result'] ) ) {
			$result  = sanitize_key( wp_unslash( $_GET['acps_page_result'] ) );
			$page_id = isset( $_GET['acps_page_id'] ) ? (int) $_GET['acps_page_id'] : 0;
			$view    = $page_id ? ' <a href="' . esc_url( get_permalink( $page_id ) ) . '">' . esc_html__( 'View page', 'acps-sitemap' ) . '</a>' : '';

			if ( 'created' === $result ) {
				echo '<div class="notice notice-success is-dismissible"><p>'
					. esc_html__( 'Sitemap page created.', 'acps-sitemap' ) . wp_kses_post( $view )
					. '</p></div>';
			} elseif ( 'exists' === $result ) {
				echo '<div class="notice notice-info is-dismissible"><p>'
					. esc_html__( 'A page with the slug "sitemap" already exists.', 'acps-sitemap' ) . wp_kses_post( $view )
					. '</p></div>';
			} else {
				echo '<div class="notice notice-error is-dismissible"><p>'
					. esc_html__( 'Could not create the sitemap page.', 'acps-sitemap' )
					. '</p></div>';
			}
		}

		if ( ! empty( $_GET['acps_checked'] ) ) {
			$status = ACPS_Sitemap_Updater::peek_status();
			if ( $status['has_update'] && ! empty( $status['remote']['version'] ) ) {
				echo '<div class="notice notice-warning is-dismissible"><p>'
					. sprintf(
						/* translators: %s: version number. */
						esc_html__( 'Update available: version %s. It will appear on the Plugins screen.', 'acps-sitemap' ),
						esc_html( $status['remote']['version'] )
					)
					. '</p></div>';
			} elseif ( $status['checked'] && $status['remote'] ) {
				echo '<div class="notice notice-success is-dismissible"><p>'
					. esc_html__( 'You are running the latest version.', 'acps-sitemap' )
					. '</p></div>';
			} else {
				echo '<div class="notice notice-error is-dismissible"><p>'
					. esc_html__( 'Could not reach the configured update source. Check the source settings below.', 'acps-sitemap' )
					. '</p></div>';
			}
		}

		if ( ! empty( $_GET['acps_pw'] ) ) {
			$pw = sanitize_key( wp_unslash( $_GET['acps_pw'] ) );
			if ( 'pw_set' === $pw ) {
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Control panel password saved.', 'acps-sitemap' ) . '</p></div>';
			} elseif ( 'pw_cleared' === $pw ) {
				echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'Control panel password removed. The panel cannot be signed into until a new one is set.', 'acps-sitemap' ) . '</p></div>';
			}
		}
	}

	/* --------------------------------------------------------------------- *
	 * Page rendering.
	 * --------------------------------------------------------------------- */

	/**
	 * Render the settings page. Guarded so an unexpected error shows a plain
	 * message instead of fataling the admin screen.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		try {
			$this->render_page_inner();
		} catch ( \Throwable $e ) {
			echo '<div class="wrap"><h1>' . esc_html__( 'ACPS Sitemap', 'acps-sitemap' ) . '</h1>';
			echo '<div class="notice notice-error"><p>' . esc_html__( 'The settings screen hit an error and could not render fully.', 'acps-sitemap' ) . '</p></div></div>';
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( '[ACPS Sitemap] render_page: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
			}
		}
	}

	/**
	 * Actual settings-page markup.
	 */
	private function render_page_inner() {
		$settings   = ACPS_Sitemap::get_settings();
		$xml        = acps_sitemap()->xml;
		$index_url  = $xml->index_url();
		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		$taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
		$create_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=acps_sitemap_create_page' ),
			'acps_sitemap_create_page'
		);
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'ACPS Sitemap', 'acps-sitemap' ); ?></h1>

			<div class="notice notice-info inline" style="margin:15px 0;padding:12px 12px;">
				<p style="margin:0 0 6px;">
					<strong><?php esc_html_e( 'Your XML sitemap:', 'acps-sitemap' ); ?></strong>
					<a href="<?php echo esc_url( $index_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $index_url ); ?></a>
				</p>
				<p style="margin:0;">
					<?php esc_html_e( 'HTML sitemap for visitors: add the shortcode', 'acps-sitemap' ); ?>
					<code>[acps_sitemap]</code>
					<?php esc_html_e( 'to any page.', 'acps-sitemap' ); ?>
				</p>
			</div>

			<?php
			$missing_files = function_exists( 'acps_sitemap_missing_files' ) ? acps_sitemap_missing_files() : array();
			$total_files   = function_exists( 'acps_sitemap_required_files' ) ? count( acps_sitemap_required_files() ) : 0;
			?>
			<p style="margin:10px 0;">
				<?php if ( empty( $missing_files ) ) : ?>
					<span class="dashicons dashicons-yes" style="color:#46b450;vertical-align:middle;"></span>
					<?php
					/* translators: %d: number of files. */
					printf( esc_html__( 'Plugin health: all %d core files present.', 'acps-sitemap' ), (int) $total_files );
					?>
				<?php else : ?>
					<span class="dashicons dashicons-warning" style="color:#dc3232;vertical-align:middle;"></span>
					<?php
					/* translators: 1: missing count, 2: total count, 3: file list. */
					printf(
						esc_html__( 'Plugin health: %1$d of %2$d core files missing (%3$s). Reinstall the plugin.', 'acps-sitemap' ),
						count( $missing_files ),
						(int) $total_files,
						esc_html( implode( ', ', $missing_files ) )
					);
					?>
				<?php endif; ?>
			</p>

			<form action="options.php" method="post">
				<?php settings_fields( 'acps_sitemap_group' ); ?>
				<input type="hidden" name="<?php echo esc_attr( ACPS_Sitemap::OPTION ); ?>[_form]" value="general" />

				<h2><?php esc_html_e( 'Sitemap options', 'acps-sitemap' ); ?></h2>
				<table class="form-table" role="presentation">
					<tbody>
					<tr>
						<th scope="row"><?php esc_html_e( 'XML sitemap', 'acps-sitemap' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( ACPS_Sitemap::OPTION ); ?>[enable_xml]" value="1" <?php checked( $settings['enable_xml'], 1 ); ?> />
								<?php esc_html_e( 'Enable the XML sitemap for search engines', 'acps-sitemap' ); ?>
							</label>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Include post types', 'acps-sitemap' ); ?></th>
						<td>
							<?php foreach ( $post_types as $pt ) : ?>
								<label style="display:inline-block;min-width:180px;margin:0 0 6px;">
									<input type="checkbox"
										name="<?php echo esc_attr( ACPS_Sitemap::OPTION ); ?>[post_types][]"
										value="<?php echo esc_attr( $pt->name ); ?>"
										<?php checked( in_array( $pt->name, (array) $settings['post_types'], true ) ); ?> />
									<?php echo esc_html( $pt->labels->name ); ?>
									<span style="color:#888;">(<?php echo esc_html( $pt->name ); ?>)</span>
								</label>
							<?php endforeach; ?>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Include taxonomies', 'acps-sitemap' ); ?></th>
						<td>
							<?php if ( empty( $taxonomies ) ) : ?>
								<em><?php esc_html_e( 'No public taxonomies found.', 'acps-sitemap' ); ?></em>
							<?php else : ?>
								<?php foreach ( $taxonomies as $tax ) : ?>
									<label style="display:inline-block;min-width:180px;margin:0 0 6px;">
										<input type="checkbox"
											name="<?php echo esc_attr( ACPS_Sitemap::OPTION ); ?>[taxonomies][]"
											value="<?php echo esc_attr( $tax->name ); ?>"
											<?php checked( in_array( $tax->name, (array) $settings['taxonomies'], true ) ); ?> />
										<?php echo esc_html( $tax->labels->name ); ?>
										<span style="color:#888;">(<?php echo esc_html( $tax->name ); ?>)</span>
									</label>
								<?php endforeach; ?>
							<?php endif; ?>
							<p class="description"><?php esc_html_e( 'Category and tag archive pages, if you want them in the sitemap.', 'acps-sitemap' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="acps-exclude"><?php esc_html_e( 'Exclude IDs', 'acps-sitemap' ); ?></label></th>
						<td>
							<input type="text" class="regular-text" id="acps-exclude"
								name="<?php echo esc_attr( ACPS_Sitemap::OPTION ); ?>[exclude_ids]"
								value="<?php echo esc_attr( implode( ', ', (array) $settings['exclude_ids'] ) ); ?>" />
							<p class="description"><?php esc_html_e( 'Comma-separated post/page IDs to leave out of the sitemap.', 'acps-sitemap' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="acps-max"><?php esc_html_e( 'URLs per sitemap', 'acps-sitemap' ); ?></label></th>
						<td>
							<input type="number" min="1" max="50000" step="1" id="acps-max"
								name="<?php echo esc_attr( ACPS_Sitemap::OPTION ); ?>[max_per_sitemap]"
								value="<?php echo esc_attr( (int) $settings['max_per_sitemap'] ); ?>" />
							<p class="description"><?php esc_html_e( 'Larger sets are split across multiple sitemap files automatically.', 'acps-sitemap' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Search engines', 'acps-sitemap' ); ?></th>
						<td>
							<label style="display:block;margin-bottom:6px;">
								<input type="checkbox" name="<?php echo esc_attr( ACPS_Sitemap::OPTION ); ?>[add_to_robots]" value="1" <?php checked( $settings['add_to_robots'], 1 ); ?> />
								<?php esc_html_e( 'Reference the sitemap in robots.txt', 'acps-sitemap' ); ?>
							</label>
							<label style="display:block;">
								<input type="checkbox" name="<?php echo esc_attr( ACPS_Sitemap::OPTION ); ?>[disable_core_sitemap]" value="1" <?php checked( $settings['disable_core_sitemap'], 1 ); ?> />
								<?php esc_html_e( 'Turn off the built-in WordPress sitemap (wp-sitemap.xml) to avoid duplicates', 'acps-sitemap' ); ?>
							</label>
						</td>
					</tr>
					</tbody>
				</table>

				<?php submit_button( __( 'Save sitemap options', 'acps-sitemap' ) ); ?>
			</form>

			<hr />

			<h2><?php esc_html_e( 'HTML sitemap page', 'acps-sitemap' ); ?></h2>
			<p><?php esc_html_e( 'Create a visitor-facing "Sitemap" page that uses the shortcode automatically.', 'acps-sitemap' ); ?></p>
			<p>
				<a href="<?php echo esc_url( $create_url ); ?>" class="button button-secondary">
					<?php esc_html_e( 'Create sitemap page', 'acps-sitemap' ); ?>
				</a>
			</p>

			<?php
			// The Updates panel is intentionally hidden. It renders only when the
			// URL carries &updates=1, so there is no visible link or mention of it
			// anywhere in the admin; reach it by typing that URL directly.
			if ( isset( $_GET['updates'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				?>
				<hr />
				<?php $this->render_updates_section( $settings ); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render the self-hosted updates panel.
	 *
	 * @param array $settings Current settings.
	 */
	private function render_updates_section( $settings ) {
		$status     = ACPS_Sitemap_Updater::peek_status();
		$force_url  = ACPS_Sitemap_Updater::force_update_url();
		$status_url = rest_url( ACPS_SITEMAP_REST_NAMESPACE . '/update-status' );
		$check_url  = wp_nonce_url(
			admin_url( 'admin-post.php?action=acps_sitemap_check_updates' ),
			'acps_sitemap_check_updates'
		);
		$opt = esc_attr( ACPS_Sitemap::OPTION );
		?>
		<h2><?php esc_html_e( 'Updates', 'acps-sitemap' ); ?></h2>
		<p class="description" style="max-width:46em;">
			<?php esc_html_e( 'Let this plugin update itself from a source you control (a GitHub release or a JSON manifest), even though it is not on the WordPress.org directory. A new version is crash-tested after install; if it fails to load it is rolled back automatically.', 'acps-sitemap' ); ?>
		</p>

		<table class="form-table" role="presentation">
			<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( 'Status', 'acps-sitemap' ); ?></th>
				<td>
					<p style="margin:0 0 4px;">
						<?php
						printf(
							/* translators: %s: version number. */
							esc_html__( 'Installed version: %s', 'acps-sitemap' ),
							'<strong>' . esc_html( ACPS_SITEMAP_VERSION ) . '</strong>'
						);
						?>
					</p>
					<p style="margin:0 0 8px;">
						<?php
						if ( $status['has_update'] && ! empty( $status['remote']['version'] ) ) {
							printf(
								/* translators: %s: version number. */
								esc_html__( 'Update available: %s', 'acps-sitemap' ),
								'<strong>' . esc_html( $status['remote']['version'] ) . '</strong>'
							);
						} elseif ( $status['checked'] && $status['remote'] ) {
							esc_html_e( 'Up to date.', 'acps-sitemap' );
						} else {
							esc_html_e( 'Not checked yet (or source unreachable).', 'acps-sitemap' );
						}
						?>
					</p>
					<?php $failed = get_option( 'acps_sitemap_update_failed' ); ?>
					<?php if ( is_array( $failed ) && ! empty( $failed ) ) : ?>
						<p class="notice notice-error" style="padding:8px 10px;margin:0 0 8px;">
							<?php
							esc_html_e( 'A recent update failed its load test and was rolled back / kept disabled to protect the site.', 'acps-sitemap' );
							if ( ! empty( $failed['when'] ) ) {
								echo ' ' . esc_html( $failed['when'] );
							}
							?>
						</p>
					<?php endif; ?>
					<a href="<?php echo esc_url( $check_url ); ?>" class="button button-secondary"><?php esc_html_e( 'Check for updates now', 'acps-sitemap' ); ?></a>
				</td>
			</tr>
			</tbody>
		</table>

		<form action="options.php" method="post">
			<?php settings_fields( 'acps_sitemap_group' ); ?>
			<input type="hidden" name="<?php echo $opt; ?>[_form]" value="updates" />

			<table class="form-table" role="presentation">
				<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable updates', 'acps-sitemap' ); ?></th>
					<td>
						<label style="display:block;margin-bottom:6px;">
							<input type="checkbox" name="<?php echo $opt; ?>[update_enabled]" value="1" <?php checked( $settings['update_enabled'], 1 ); ?> />
							<?php esc_html_e( 'Check the source and show "Update now" on the Plugins screen', 'acps-sitemap' ); ?>
						</label>
						<label style="display:block;">
							<input type="checkbox" name="<?php echo $opt; ?>[update_auto]" value="1" <?php checked( $settings['update_auto'], 1 ); ?> />
							<?php esc_html_e( 'Install updates automatically in the background', 'acps-sitemap' ); ?>
						</label>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="acps-update-source"><?php esc_html_e( 'Update source', 'acps-sitemap' ); ?></label></th>
					<td>
						<select id="acps-update-source" name="<?php echo $opt; ?>[update_source]">
							<option value="github" <?php selected( $settings['update_source'], 'github' ); ?>><?php esc_html_e( 'GitHub Releases', 'acps-sitemap' ); ?></option>
							<option value="url" <?php selected( $settings['update_source'], 'url' ); ?>><?php esc_html_e( 'JSON manifest URL', 'acps-sitemap' ); ?></option>
						</select>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'GitHub source', 'acps-sitemap' ); ?></th>
					<td>
						<p style="margin:0 0 6px;">
							<input type="text" class="regular-text" placeholder="<?php esc_attr_e( 'owner', 'acps-sitemap' ); ?>"
								name="<?php echo $opt; ?>[gh_owner]" value="<?php echo esc_attr( $settings['gh_owner'] ); ?>" />
							<span>/</span>
							<input type="text" class="regular-text" placeholder="<?php esc_attr_e( 'repo', 'acps-sitemap' ); ?>"
								name="<?php echo $opt; ?>[gh_repo]" value="<?php echo esc_attr( $settings['gh_repo'] ); ?>" />
						</p>
						<p style="margin:0 0 6px;">
							<label><?php esc_html_e( 'Release asset filename', 'acps-sitemap' ); ?>
								<input type="text" class="regular-text"
									name="<?php echo $opt; ?>[gh_asset]" value="<?php echo esc_attr( $settings['gh_asset'] ); ?>" />
							</label>
						</p>
						<p style="margin:0;">
							<label><?php esc_html_e( 'Access token (only for private repos)', 'acps-sitemap' ); ?>
								<input type="password" class="regular-text" autocomplete="new-password"
									name="<?php echo $opt; ?>[gh_token]" value="<?php echo esc_attr( $settings['gh_token'] ); ?>" />
							</label>
						</p>
						<p class="description"><?php esc_html_e( 'The release tag (minus a leading "v") is the version. The asset should be a zip that unpacks to the plugin folder.', 'acps-sitemap' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'Manifest source', 'acps-sitemap' ); ?></th>
					<td>
						<p style="margin:0 0 6px;">
							<input type="url" class="large-text" placeholder="https://example.org/acps-sitemap.json"
								name="<?php echo $opt; ?>[update_manifest]" value="<?php echo esc_attr( $settings['update_manifest'] ); ?>" />
						</p>
						<p style="margin:0;">
							<label><?php esc_html_e( 'Optional access key (sent as ?key=)', 'acps-sitemap' ); ?>
								<input type="text" class="regular-text"
									name="<?php echo $opt; ?>[update_manifest_key]" value="<?php echo esc_attr( $settings['update_manifest_key'] ); ?>" />
							</label>
						</p>
						<p class="description"><?php esc_html_e( 'A JSON file returning at least {"version","download_url"}.', 'acps-sitemap' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="acps-update-role"><?php esc_html_e( 'Rollout role', 'acps-sitemap' ); ?></label></th>
					<td>
						<select id="acps-update-role" name="<?php echo $opt; ?>[update_role]">
							<option value="standalone" <?php selected( $settings['update_role'], 'standalone' ); ?>><?php esc_html_e( 'Standalone (update directly)', 'acps-sitemap' ); ?></option>
							<option value="dev" <?php selected( $settings['update_role'], 'dev' ); ?>><?php esc_html_e( 'Dev / staging (verify first)', 'acps-sitemap' ); ?></option>
							<option value="production" <?php selected( $settings['update_role'], 'production' ); ?>><?php esc_html_e( 'Production (wait for dev to verify)', 'acps-sitemap' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Optional staged rollout. A production site only updates once the paired dev site has installed and verified the version.', 'acps-sitemap' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'Staged rollout link', 'acps-sitemap' ); ?></th>
					<td>
						<p style="margin:0 0 6px;">
							<label><?php esc_html_e( 'Dev status URL (production only)', 'acps-sitemap' ); ?>
								<input type="url" class="large-text"
									name="<?php echo $opt; ?>[verify_status_url]" value="<?php echo esc_attr( $settings['verify_status_url'] ); ?>" />
							</label>
						</p>
						<p style="margin:0;">
							<label><?php esc_html_e( 'Shared status key', 'acps-sitemap' ); ?>
								<input type="text" class="regular-text"
									name="<?php echo $opt; ?>[verify_status_key]" value="<?php echo esc_attr( $settings['verify_status_key'] ); ?>" />
							</label>
						</p>
						<p class="description">
							<?php esc_html_e( 'This site publishes its verified status at:', 'acps-sitemap' ); ?>
							<code><?php echo esc_html( $status_url ); ?></code>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'Remote control panel', 'acps-sitemap' ); ?></th>
					<td>
						<label style="display:block;margin-bottom:6px;">
							<input type="checkbox" name="<?php echo $opt; ?>[remote_enabled]" value="1" <?php checked( $settings['remote_enabled'], 1 ); ?> />
							<?php esc_html_e( 'Enable the secret out-of-band control panel (served from the URL below)', 'acps-sitemap' ); ?>
						</label>
						<?php if ( '' !== $force_url ) : ?>
							<input type="text" class="large-text code" readonly onclick="this.select();" value="<?php echo esc_attr( $force_url ); ?>" />
							<p class="description"><?php esc_html_e( 'Keep this URL secret. It is IP-restricted, password-protected and rate-limited. Loading it opens the panel (diagnostics, updates, and once-a-day settings editing).', 'acps-sitemap' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'Control panel access (IP)', 'acps-sitemap' ); ?></th>
					<td>
						<p style="margin:0 0 6px;">
							<select name="<?php echo $opt; ?>[remote_ip_mode]">
								<option value="allow" <?php selected( $settings['remote_ip_mode'], 'allow' ); ?>><?php esc_html_e( 'Allow only the IPs listed below', 'acps-sitemap' ); ?></option>
								<option value="deny" <?php selected( $settings['remote_ip_mode'], 'deny' ); ?>><?php esc_html_e( 'Block the IPs listed below (allow everyone else)', 'acps-sitemap' ); ?></option>
							</select>
							<select name="<?php echo $opt; ?>[remote_ip_source]">
								<option value="remote_addr" <?php selected( $settings['remote_ip_source'], 'remote_addr' ); ?>>REMOTE_ADDR</option>
								<option value="x_forwarded_for" <?php selected( $settings['remote_ip_source'], 'x_forwarded_for' ); ?>>X-Forwarded-For</option>
							</select>
						</p>
						<p style="margin:0 0 6px;">
							<textarea name="<?php echo $opt; ?>[remote_ip_list]" rows="4" class="large-text code"><?php echo esc_textarea( implode( "\n", (array) $settings['remote_ip_list'] ) ); ?></textarea>
						</p>
						<p class="description"><?php esc_html_e( 'One rule per line: an exact IP (167.102.110.1), a prefix/wildcard (196.168.*), or a CIDR range (10.0.0.0/8). If your site is behind a proxy/CDN, choose X-Forwarded-For.', 'acps-sitemap' ); ?></p>
						<p style="margin:6px 0 0;">
							<label><?php esc_html_e( 'Max requests per 5 minutes', 'acps-sitemap' ); ?>
								<input type="number" min="1" max="100000" name="<?php echo $opt; ?>[remote_rate_max]" value="<?php echo esc_attr( (int) $settings['remote_rate_max'] ); ?>" />
							</label>
						</p>
					</td>
				</tr>
				</tbody>
			</table>

			<?php submit_button( __( 'Save update settings', 'acps-sitemap' ) ); ?>
		</form>

		<?php $this->render_remote_password_form(); ?>
		<?php
	}

	/**
	 * A separate form (its own admin-post handler) to set the remote-panel
	 * password. Kept out of the settings array and hashed on save; this is the
	 * only place the password can be changed.
	 */
	private function render_remote_password_form() {
		$has_pw   = (bool) get_option( ACPS_Sitemap_Remote::PW_OPTION );
		$post_url = wp_nonce_url( admin_url( 'admin-post.php?action=acps_sitemap_set_remote_pw' ), 'acps_sitemap_set_remote_pw' );
		?>
		<h2><?php esc_html_e( 'Control panel password', 'acps-sitemap' ); ?></h2>
		<p class="description" style="max-width:46em;">
			<?php
			echo $has_pw
				? esc_html__( 'A password is set. Enter a new one to change it, or leave blank and save to remove it (which disables sign-in to the panel).', 'acps-sitemap' )
				: esc_html__( 'No password is set yet. The control panel cannot be used until you set one here.', 'acps-sitemap' );
			?>
		</p>
		<form action="<?php echo esc_url( $post_url ); ?>" method="post">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="acps-remote-pw"><?php esc_html_e( 'New password', 'acps-sitemap' ); ?></label></th>
					<td>
						<input type="password" id="acps-remote-pw" name="acps_remote_pw" class="regular-text" autocomplete="new-password" />
						<p class="description"><?php esc_html_e( 'Stored hashed. Use a long, unique password.', 'acps-sitemap' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save password', 'acps-sitemap' ), 'secondary' ); ?>
		</form>
		<?php
	}
}
