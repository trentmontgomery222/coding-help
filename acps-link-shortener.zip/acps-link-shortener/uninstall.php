<?php
/**
 * Uninstall routine.
 *
 * By default we PRESERVE the links table and options so that deleting/replacing
 * the plugin never destroys live short links (build brief, Open Question #4).
 *
 * To opt into a full teardown on uninstall, define this in wp-config.php:
 *
 *     define( 'ACPS_LS_DROP_DATA_ON_UNINSTALL', true );
 *
 * @package ACPS_Link_Shortener
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! defined( 'ACPS_LS_DROP_DATA_ON_UNINSTALL' ) || ! ACPS_LS_DROP_DATA_ON_UNINSTALL ) {
	// Preserve everything. Do nothing.
	return;
}

global $wpdb;

$table = $wpdb->prefix . 'acps_links';
// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DROP TABLE IF EXISTS {$table}" );

delete_option( 'acps_ls_db_version' );
delete_option( 'acps_ls_settings' );
delete_option( 'acps_ls_last_sync' );

// Self-updater state.
delete_option( 'acps_ls_safe_mode' );
delete_option( 'acps_ls_update_failed' );
delete_option( 'acps_ls_verified' );
delete_option( 'acps_ls_staged_install' );
delete_option( 'acps_ls_rollback' );
delete_option( 'acps_ls_pending_update' );
delete_option( 'acps_ls_pending_result' );
delete_option( 'acps_ls_should_be_active' );
delete_transient( 'acps_ls_update_remote' );
delete_transient( 'acps_ls_devstatus' );
delete_transient( 'acps_ls_pending_lock' );
wp_clear_scheduled_hook( 'acps_ls_apply_pending' );

// NOTE: API keys live inside the acps_ls_settings option (deleted above), so no
// separate cleanup is needed for them.

// Clear any scheduled sync.
wp_clear_scheduled_hook( 'acps_ls_sheet_sync' );
