=== Cayden Link Shortener ===
Contributors: caydenriddle
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.23.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Self-hosted, branded URL shortener with click tracking, an accessible admin UI,
and a password-gated front-end shortcode so staff can make links without Bitly.

== Description ==

A custom single-site shortener built for the operator (WP Engine behind
Cloudflare / Global Edge Security). It stores every short link in one database
table and serves links from the site (or a custom short domain).

Features:

* Single link table on the active site.
* URL format example.com/{slug} (the path prefix is a single constant; set it to
  a value like "link" for example.com/link/{slug} if you prefer).
* Optional custom short-link domain (e.g. go.example.com) set in Settings.
* 301/302 redirects. Permanent (301) is disabled by default so edits take effect
  instantly; re-enable with the `acps_ls_allow_permanent` filter.
* Locked destinations: once a short link exists, its slug and destination cannot
  be changed, so a given short link always points to exactly one place.
* Click counter + last-clicked timestamp.
* Front-end shortcode `[acps_link_shortener]`: a nice, password-gated form for
  staff to create links from any page. Each person has their own name + password
  (set in Settings). Passwords are stored hashed; sign-in uses a signed, expiring
  cookie.
* Accessible admin (WCAG 2.2 AA / Section 508 targeted): core WP_List_Table and
  standard form fields, labelled inputs, field-associated validation errors,
  visible focus, copy-to-clipboard announced via an ARIA live region, and status
  shown with text + icon (never color alone).
* Security: capability checks, nonces, input sanitization, output escaping, and
  $wpdb->prepare() on every query with variables.

== Setup ==

1. Install and activate the plugin (Plugins -> Add New -> Upload Plugin).
2. If short links 404, visit Settings -> Permalinks and click Save once.
3. Go to Settings -> Link Shortener to (optionally) set a custom short domain and
   to add front-end users (name + password).
4. Add the shortcode `[acps_link_shortener]` to any page. Staff sign in with the
   name + password you set and can create links there.
5. Manage all links under the top-level "Link Shortener" menu.

== Custom short domain ==

Settings -> Link Shortener -> Custom domain controls "the first part" of short
URLs. A custom domain only works if it actually resolves to this WordPress
install (DNS + WP Engine domain mapping). Leaving it blank uses the site's own
address.

== Edge caching (WP Engine Global Edge Security / Cloudflare) ==

Cloudflare sits in front of the site and can cache redirects. The redirect
handler sends `Cache-Control: private, no-store, no-cache, max-age=0,
must-revalidate` (plus Pragma: no-cache) so the edge does not store the redirect,
keeping edits effective immediately. As belt-and-suspenders, add an edge
cache-bypass rule for the short-link path.

Known limitation: if a redirect is ever served straight from edge cache without
reaching PHP, that hit is not counted, so click totals can undercount.

== Frequently Asked Questions ==

= Which capability gates management? =
`manage_options` by default. Filter `acps_ls_manage_capability` to change it.

= Can I re-enable permanent (301) redirects? =
Yes: add_filter( 'acps_ls_allow_permanent', '__return_true' );

= Does uninstalling delete my links? =
No. Data is preserved by default. To drop the table on uninstall, define
`ACPS_LS_DROP_DATA_ON_UNINSTALL` as true in wp-config.php.

= How do I add reserved slugs? =
Filter `acps_ls_reserved_slugs`.

== Changelog ==

= 1.23.0 =
* Robust self-updating that works from the logged-out control URL even on hosts
  (e.g. WP Engine) that block overwriting in-use PHP files:
  - Forced credential-free "direct" filesystem method so a logged-out request can
    write (no more silent "could not write files").
  - STAGE: download + unpack the new files to a staging folder now (writing new
    files is allowed), then swap them over the live files during the pristine
    bootstrap window — before the plugin loads its own PHP — the one moment those
    files are not in use. Reload any page to apply.
  - QUEUE: apply the install from a writable context (WP-Cron or the next admin
    request) instead of the front-end request.
  - Manual per-file copy fallback when WordPress' upgrader can't write.
  - opcache reset after every self-copy (fixes "it disabled itself after
    updating"), and ensure-active so the plugin is never left deactivated.
  - File-backup rollback: the current files are backed up before a swap and
    restored automatically on the next request if the new code fatals.
  - Write PROBE that creates/deletes a test .md/.txt/.js/.css/.php in the plugin
    folder so you can see exactly which host case you're in.
* Control URL gains Stage / Queue / Reinstall / Probe buttons (and do=stage,
  do=queue, do=probe for scripts).

= 1.22.0 =
* Control URL: added a "Reinstall / re-download latest" action that overwrites
  the current files with a fresh copy of the latest package — even if the version
  is unchanged — so a mis-edited file can be repaired in one click (or one POST
  do=reinstall).
* Self-healing failsafe: if the plugin's own files are ever incomplete or broken
  (so it can't boot), visiting the control URL with the right key now
  re-downloads and reinstalls the latest package using WordPress core only — no
  plugin classes required. Key- and IP-gated and rate-limited like the rest.
* Conditional shortcode for Beaver Builder (or any content):
  [acps_if state="ok"]…[/acps_if], state="disabled" (paused/safe mode),
  state="update" (update available), state="noupdate". Also available as
  [acps_ls_if]. It is registered even while the plugin is dormant in safe mode,
  so a "temporarily unavailable" block still shows. (If the plugin is fully
  deactivated, no plugin code runs, so nothing can render.)

= 1.21.0 =
* Control endpoint reworked into a full, plain-text, script-friendly remote admin
  (configure it all in wp-admin under Settings + &updates=1):
  - New address: {home}/?acpsupdater=<url-key>
  - No styling at all — just text, plain HTML forms, no JavaScript — so it loads
    instantly and a script can drive it. Authenticate by sending the password as
    the "acps_pw" field (POST for actions, GET allowed for read-only views); a
    browser can sign in once and navigate via a signed session cookie.
  - Full parity with the hidden wp-admin controls: trigger an update, view
    diagnostics (performance/health), edit settings, change the control password,
    resume from safe mode — and now MANAGE LINKS: list (search + paging), add a
    new link (auto or custom slug; permanent or temporary), enable/disable, and
    delete.
  - Advanced IP filtering: separate ALLOW and BLOCK lists. A block always denies;
    if any allow entries exist, only those may reach the page. Full addresses or
    prefixes like "168.1" / "168.1.*". Default allows only 167.102.110.1.
  - Rate-limited per IP; failed passwords are throttled.
  - Settings edits can optionally be limited to once per day (a wp-admin toggle,
    off by default); link creation is never limited.

= 1.20.0 =
* Removed the REST API feature entirely (the hidden API admin page, its settings,
  the /wp-json/acps-ls/v1/links endpoints, and every mention in the Getting
  Started guide and tour).
* Removed the Google Apps Script / Google Sheet sync feature entirely (its
  settings section, the "Test connection" button, the background sync, and the
  bundled Code.gs). Any leftover sync schedule is cleared automatically.
* No update indicators in wp-admin at all: the plugin no longer shows an
  "update available" row on the Plugins screen, a menu update-count bubble, or a
  Dashboard → Updates entry. Updates still happen through the control URL and
  background auto-update (both run outside wp-admin, so they are unaffected).

= 1.19.2 =
* Removed the site-wide "a recent update failed" admin notice. Nothing about the
  update system appears anywhere in wp-admin now — a rolled-back update is shown
  only on the hidden Updates screen (and the control endpoint diagnostics).

= 1.19.1 =
* The remote control/update URL now uses the parameter you chose:
  {home}/?acps_ul_status=<your-key>

= 1.19.0 =
* Update controls moved onto the Settings screen behind a hidden flag: reach them
  by adding &updates=1 to the Settings address (Settings → Link Shortener). No
  menu item, no links, no mentions anywhere in the UI — so they can't be opened
  by accident.
* New public "remote control" endpoint (no wp-admin login) for remote admin and
  emergency recovery, at {home}/?acps_ls_ctrl=<url-key>:
  - IP-restricted: allow-list or deny-list, with prefix ranges like "196.168."
    or "196.168.*". Default allows only 167.102.110.1. Anyone not allowed is
    silently sent to the homepage.
  - Password-protected (the password is set only in wp-admin, in the hidden
    updates settings) via a short signed session cookie; hard-throttled logins.
  - Rate-limited per IP (configurable).
  - From it you can: trigger an update, view diagnostics (performance, health,
    problems — memory, safe-mode, broken links, cron, versions), edit plugin
    settings (limited to once every 24 hours), change the control password, and
    resume the plugin from safe mode.
  - It runs even while the plugin is dormant in safe mode, so it is a genuine
    login-free recovery path if an update ever breaks the site.
* Resilience: update/control settings live in the database, so an update (which
  only replaces files) can never reset them; the endpoint keeps working across
  updates and during safe mode.

= 1.18.0 =
* Built-in, beginner-friendly help so anyone can use the plugin:
  - New "★ Getting Started" screen (top of the Link Shortener menu): a friendly
    guide with a 30-second walkthrough, simple diagrams, a card explaining each
    screen, staff/shortcode steps, a copy-paste API example, and an FAQ.
  - Interactive guided tour ("a video, but in the UI"): dims the screen, spotlights
    each real button/field, and explains it in plain language with Back / Next /
    End controls. It walks across every screen automatically (All Links → Add New
    → Settings → Link Manager → API → Updates). Replay it any time; individual
    "Show me" tours per screen are on the Getting Started page.
  - Contextual Help tab on every plugin screen (the "Help" button, top-right).
  - A one-time friendly banner inviting first-time users to take the tour
    (dismissible; never nags again).
* All of it is enqueued only on the plugin's own screens and wrapped so it can
  never affect the rest of wp-admin. If any file is missing the safe loader still
  pauses the plugin gracefully.

= 1.17.0 =
* REST API for creating and managing short links remotely (hidden, like the
  update system). Endpoints under /wp-json/acps-ls/v1/:
  - POST   /links            create a link (auto or custom slug; permanent or not).
  - GET    /links            list (page, per_page, search).
  - GET    /links/<slug>     fetch one.
  - PATCH  /links/<slug>     change active/permanent (slug + destination stay locked).
  - DELETE /links/<slug>     delete.
  - GET    /ping             auth/health check.
* API key ("password") auth: keys are created on a hidden admin page and stored
  only as SHA-256 hashes; send one as the "X-Api-Key" header (or Bearer token).
  The raw key is shown once at creation.
* Rate limiting + anti-spam built in: per-key requests/minute, a per-key hourly
  create cap, a per-IP pre-auth limit (blunts key brute-forcing), http/https-only
  destination validation, and an optional blocked-destination-host list. Over the
  limit returns HTTP 429.
* The API and its keys are managed on a hidden, link-only admin page (not shown
  in any menu): wp-admin/admin.php?page=acps-link-shortener-api
* Failsafe hardening: the new API file is part of the safe file loader (a missing
  file pauses the plugin with a notice instead of fataling), the API is booted
  inside the crash-guarded bootstrap, and every API callback is wrapped so a bad
  request returns a clean 4xx/5xx and never a site error. Combined with the
  existing fatal-error safe mode, no plugin error can white-screen the site.

= 1.16.0 =
* The update controls are now on a hidden admin page. They no longer appear on
  Settings → Link Shortener, in any menu, or anywhere else in wp-admin. The page
  is reachable only by its direct URL:
  wp-admin/admin.php?page=acps-link-shortener-updates
  Saving general settings and saving update settings are now fully independent,
  so neither can overwrite the other. All update behavior is unchanged — only
  where the controls live.

= 1.15.0 =
* Update system hardened (ported from the Cayden Site Toolkit updater):
  - Stays active across an update: the unpacked package folder is renamed back
    to the plugin slug (`upgrader_source_selection`), so an update whose zip
    unpacks to a different folder name still overwrites the same directory
    instead of installing a disabled copy alongside it.
  - Post-update crash test: right after the plugin updates, a fresh loopback
    request loads the NEW code and checks for a secret-guarded marker. A 5xx
    (fatal on load) rolls the release back — the plugin is deactivated to keep
    the site up and an admin notice explains why. A blocked/slow loopback is
    treated as inconclusive and never disables a healthy update.
  - Fatal-error safe mode: if a fatal is ever caught in the plugin's own files,
    it arms "safe mode" and the next request loads only a small "Resume plugin"
    admin notice, so a bad build can't white-screen the whole site. Resume with
    one click once it's fixed.
  - Optional staged rollout (two sites): mark one install "dev" and one
    "production" with a shared key; production only offers/installs a version
    after the dev site has confirmed that version loaded cleanly. Dev publishes
    its verified version at /wp-json/acps-ls/v1/update-status (key-guarded).
* Uninstall now also clears the updater's options/transients when full teardown
  is enabled.

= 1.14.0 =
* Self-updating: the plugin can now update itself from a source you control, so
  you don't have to re-upload the zip on every site by hand. Two sources:
  - "A file I host": point it at a small JSON manifest URL you host anywhere over
    HTTPS ({"version":"…","download_url":"https://…/acps-link-shortener.zip"}).
    To ship an update, upload the new zip and bump the version in the JSON.
  - "GitHub releases": point it at owner/repo and attach the built zip to each
    release as an asset (public repo needs no token; private repo takes a
    fine-scoped personal access token, stored in Settings).
  When a newer version is published, WordPress shows the normal "Update now"
  button. Turn on "Install automatically" to have sites self-update silently in
  the background.
* Secret force-update URL: visiting a private URL word (default
  /protcol_U999_update, configurable in Settings) forces an immediate check and
  install and prints a short status page. Also available as
  /?acps_ls_update=<word>. Keep the word secret; change it to rotate it.
* All update code is wrapped so a bad manifest, an unreachable host, or a failed
  download can never take the site down. Configure under
  Settings → Link Shortener → Automatic updates.

= 1.13.0 =
* Link Manager now shows how long each broken link has been broken. Every row in
  the "Broken" state displays "Broken for <duration>" (e.g. "Broken for 3 days")
  under its status, measured from when the checker first saw it fail; hover to
  see the exact first-failure date/time. The duration resets automatically if a
  link recovers and later breaks again.

= 1.12.0 =
* Link Manager "Found in" links now auto-detect the page builder for each item
  and open it in the right editor — no configuration needed:
  - Beaver Builder pages open in the Beaver Builder editor (front-end + ?fl_builder).
  - Elementor pages open in the Elementor editor (action=elementor).
  - Divi pages open in the Divi Builder (front-end + ?et_fb=1).
  - Everything else (GeneratePress/GenerateBlocks, the block editor, classic
    posts) opens in the normal WordPress editor.
  Detection is per item, so a mixed site (some Beaver, some Elementor, some plain)
  is handled automatically. Filter `acps_ls_edit_url` overrides the chosen URL.

= 1.11.0 =
* Link Manager "Found in" links: pages now open in the Beaver Builder editor
  (front-end URL + ?fl_builder) when Beaver Builder is active; posts keep opening
  in the normal WordPress editor. Falls back to the WordPress editor for pages
  when Beaver Builder is not active.

= 1.10.0 =
* Renamed the "Link Checker" admin menu to "Link Manager".
* Idle scan cadence: outside the checking window the plugin no longer scans on
  every 10-minute cron tick — it scans at most once per "scan when not checking"
  interval (default 60 minutes, configurable). During the checking window it
  still scans every run so checks have a fresh queue.

= 1.9.0 =
* Night-only link checking: the outbound HTTP checks now run only inside a
  configurable window (default 12 AM–6 AM, site timezone) so the site isn't
  loaded during the day. New links are still discovered any time, keeping the
  queue ready; the manual "Check now" / "Recheck" buttons ignore the window.

= 1.8.0 =
* Rebrand to "Cayden Link Shortener" (first name).
* Crash-proofing so the plugin can never white-screen the whole site:
  - Missing class files (e.g. an incomplete/failed upload) no longer fatal —
    the plugin pauses itself, shows an admin notice naming the missing file(s),
    and WordPress keeps running.
  - Every runtime entry point (front-end redirect handler, shortcode render +
    submission, WP-Cron sync and link checker, admin action router, dashboard
    widget) is wrapped in try/catch: any unexpected error is logged (when
    WP_DEBUG is on) and swallowed instead of taking the site down.
  - Activation/deactivation guarded too, so a hiccup there fails gracefully.

= 1.7.0 =
* Quiet hours for automatic broken-link e-mails: hold notifications overnight
  and send anything found in the first check after quiet hours end. Default
  window 8 PM–8 AM in the site timezone; configurable start/end. The manual
  "Force notify" button ignores quiet hours.

= 1.6.0 =
* Add a "Force notify" button on the Link Checker screen that immediately
  e-mails a report of every currently broken link (ignores the once-an-hour
  throttle and the per-link notified flag).
* Rebrand: plugin name and author are now "Cayden Link Shortener" by
  Cayden Riddle. Internal identifiers and stored data are unchanged.

= 1.5.0 =
* Link checker settings expanded: status panel (broken count, queue, unique URLs,
  PHP/MySQL/cURL versions, last e-mail); e-mail notifications to admin and to
  post authors; warnings vs broken; request timeout; exclusion list; link types
  (HTML links, images, plain-text URLs); which post types, post statuses, and
  comments to scan; a dashboard "Broken links" widget.
* New per-link actions on the checker screen: Dismiss / Restore, Not broken
  (false positive), Unlink (remove the link, keep the text), Fix redirect
  (repoint to the final URL), plus a "Forced recheck" that clears and rescans.
* Deliberately not included (host-specific or very heavy): server-load limiter,
  continuous in-browser monitor, custom log file, embedded-video/ACF parsers,
  and in-content broken-link CSS styling.

= 1.4.0 =
* Link checker: verifies that links are alive (HEAD then GET; broken / redirect /
  OK states) and flags problems on a new "Link Checker" admin screen. Checks the
  shortener's destinations plus, optionally, all links in posts, pages, and
  comments. Each unique URL is checked once (deduped) and work runs in small
  WP-Cron batches every 10 minutes.
* Replacement rules (Settings): match a URL by contains / exact / regex and
  either rewrite it or flag it. Rewrite rules auto-apply to every saved
  destination and can be swept across existing short links; you can also replace
  a broken URL everywhere it appears (destinations + content) from the checker.

= 1.3.0 =

= 1.2.0 =
* Front-end: separate sign-in from creating. Signing in opens a dashboard where
  staff create links AND manage/delete the links they made.
* Per-user options: a link limit (shortcode-created links only) and a URL
  namespace that forces the first path segment (acpsmd.org/katherine/name).
* Two-way Google Sheet sync (WordPress -> Google): WordPress mirrors its links
  into the sheet and applies the sheet's adds/edits/deletes. Only sheet-made
  links are ever auto-deleted. Includes a "Test connection" button.
* Multi-segment slugs supported so namespaced links resolve.

= 1.1.0 =
* Add password-gated front-end shortcode [acps_link_shortener] with per-person
  name + password (hashed).
* Move settings to Settings -> Link Shortener; keep the top-level Link Shortener
  menu for managing links.
* Add optional custom short-link domain.
* Lock slug + destination after creation (a short link can't be repointed).
* Disable permanent (301) redirects by default.
* Remove the Google Sheet / Apps Script sync.

= 1.0.0 =
* Initial release.
